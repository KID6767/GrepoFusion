# CHANGELOG

## 1.5.0.2
- Panel ustawień (FAB) + 4 motywy (Classic/Remaster/Pirate/Dark).
- Asset Map (ikonki jednostek i budynków – przykład: biremy).
- Changelog overlay przy starcie.
- Helpery: Budowniczy/Rekruter/Akademik (start, hooki).
