# GrepoFusion 1.5.0.2

**Pirate + Remaster + Classic + Dark** — motywy, panel ⚙, Asset Map (podmiana ikon), helpery (Budowniczy/Rekruter/Akademik – start).

## Instalacja
1. Zainstaluj Tampermonkey.
2. Otwórz `dist/grepofusion.user.js` (raw w repo) i zainstaluj.
3. Odśwież Grepolis. Kliknij ⚙ w prawym dolnym rogu.

## Motywy
- Classic, Remaster 2025, Pirate, Dark.

## Asset Map
- Podmiana `img.src` na odpowiedniki z `assets/assetmap.json` (Base64).
- W tej paczce: przykładowe biremy (classic/pirate) + placeholdery.

## Build
Paczka zawiera `build_grepofusion.ps1` do automatyzacji (ZIP + dist + git).
